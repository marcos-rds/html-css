19 
0:	-7,65	-5,75	-1	
1:	-6,42	-6,99	-1	
2:	-6,22	-7,13	-1	
3:	-5,97	-7,18	-1	
4:	-0,36	-7,18	-1	
5:	0,08	-6,99	-1	
6:	0,27	-6,54	-1	
7:	0,27	-0,53	-1	
8:	0,19	-0,23	-1	
9:	0,0	0,0	-1	
10:	-0,22	0,29	-1	
11:	-0,27	0,53	-1	
12:	-0,27	6,19	-1	
13:	-0,08	6,64	-1	
14:	0,36	6,82	-1	
15:	5,37	6,82	-1	
16:	5,62	6,78	-1	
17:	5,82	6,64	-1	
18:	7,06	5,4	-1	
18 
0:	0	1
1:	1	2
2:	2	3
3:	3	4
4:	4	5
5:	5	6
6:	6	7
7:	7	8
8:	8	9
9:	9	10
10:	10	11
11:	11	12
12:	12	13
13:	13	14
14:	14	15
15:	15	16
16:	16	17
17:	17	18
$$
ScaleX = 20.0
ScaleY = 10.0
StepX = 3.0
StepY = 6.0
translateX = 32.5
translateY = 75.0
espessura = 1
titleX = X
ttlX =30
txSize =14
titleY = Y
ttlY =20
tySize =14
isGrade = true
isSubGrade = false
isPview = true
isEixoView = true
isEixoAuxView = false
isEixo2AuxView = false
eixoAuxView = -431,426
eixo2AuxView = -431,426
