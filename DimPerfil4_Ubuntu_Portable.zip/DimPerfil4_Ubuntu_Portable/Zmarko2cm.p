19		
0:	-6,65	-6,75
1:	-5,42	-7,99
2:	-5,22	-8,13
3:	-4,97	-8,18
4:	-0,36	-8,18
5:	0,08	-7,99
6:	0,27	-7,54
7:	0,27	-0,53
8:	0,19	-0,23
9:	0	0
10:	-0,22	0,29
11:	-0,27	0,53
12:	-0,27	7,19
13:	-0,08	7,64
14:	0,36	7,82
15:	4,37	7,82
16:	4,62	7,78
17:	4,82	7,64
18:	6,06	6,4
18 
0:	0	1
1:	1	2
2:	2	3
3:	3	4
4:	4	5
5:	5	6
6:	6	7
7:	7	8
8:	8	9
9:	9	10
10:	10	11
11:	11	12
12:	12	13
13:	13	14
14:	14	15
15:	15	16
16:	16	17
17:	17	18
$$
ScaleX = 20.0
ScaleY = 10.0
StepX = 3.0
StepY = 6.0
translateX = 32.5
translateY = 75.0
espessura = 1
titleX = X
ttlX =30
txSize =14
titleY = Y
ttlY =20
tySize =14
isGrade = true
isSubGrade = false
isPview = true
isEixoView = true
isEixoAuxView = false
isEixo2AuxView = false
eixoAuxView = -431,426
eixo2AuxView = -431,426
