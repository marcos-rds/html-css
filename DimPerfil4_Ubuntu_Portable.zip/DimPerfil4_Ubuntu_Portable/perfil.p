13
0:	-25,0	70,0	-1	
1:	-30,0	70,0	-1	
2:	25,0	70,0	-1	
3:	30,0	70,0	-1	
4:	0,0	0,0	-1	
5:	-25,0	70,0	-1	
6:	0,0	0,0	-1	
7:	-14,28	40,0	-1	
8:	-11,0	40,0	-1	
9:	14,28	40,0	-1	
10:	11,0	40,0	-1	
11:	-18,929166793823242	53,0	-1	
12:	18,930952072143555	53,0	-1	
11
0:	1	5
1:	5	11
2:	11	7
3:	7	6
4:	6	9
5:	9	12
6:	12	2
7:	2	3
8:	12	11
9:	7	8
10:	9	10
$$
ScaleX = 20.0
ScaleY = 10.0
StepX = 3.0
StepY = 6.0
translateX = 32.5
translateY = 75.0
espessura = 1
titleX = X
ttlX =30
txSize =14
titleY = Y
ttlY =20
tySize =14
isGrade = true
isSubGrade = false
isPview = true
isEixoView = true
isEixoAuxView = false
isEixo2AuxView = false
eixoAuxView = -431,426
eixo2AuxView = -431,426