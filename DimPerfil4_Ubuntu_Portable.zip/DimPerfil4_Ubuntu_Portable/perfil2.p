13
0:	-7,65	-5,75	-1	
1:	-6,42	-6,99	-1	
2:	-5,97	-7,18	-1	
3:	-0,36	-7,18	-1	
4:	0,27	-6,54	-1	
5:	0,27	-0,53	-1	
6:	0,0	0,0	-1	
7:	-0,27	0,53	-1	
8:	-0,27	6,19	-1	
9:	0,36	6,82	-1	
10:	5,37	6,82	-1	
11:	5,82	6,64	-1	
12:	7,06	5,4	-1	
12
0:	0	1
1:	1	2
2:	2	3
3:	3	4
4:	4	5
5:	5	6
6:	6	7
7:	7	8
8:	8	9
9:	9	10
10:	10	11
11:	11	12
$$
ScaleX = 20.0
ScaleY = 10.0
StepX = 3.0
StepY = 6.0
translateX = 32.5
translateY = 75.0
espessura = 1
titleX = X
ttlX =30
txSize =14
titleY = Y
ttlY =20
tySize =14
isGrade = true
isSubGrade = false
isPview = true
isEixoView = true
isEixoAuxView = false
isEixo2AuxView = false
eixoAuxView = -431,426
eixo2AuxView = -431,426
