#!/usr/bin/env bash
set -e
HERE="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$HERE"

if ! command -v java >/dev/null 2>&1; then
  echo "Erro: Java não foi encontrado no sistema."
  echo "Neste computador, execute antes: java -version"
  read -r -p "Pressione Enter para fechar..." _ || true
  exit 1
fi

exec java -cp ".:jbcl.jar" DimPerfilProgram
